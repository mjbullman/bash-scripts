-- Neovim indent file
-- Language:	Treesitter query

-- it's a lisp!
vim.cmd([[runtime! indent/lisp.vim]])
